﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nazim.Api.Automation.Workflow
{
    public class EmployeeWorkflow
    {

    }
}
