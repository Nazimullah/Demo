﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nazim.Api.Automation.Models
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeSalary { get; set; }
        public string EmployeeDepartment { get; set; }
    }
}
